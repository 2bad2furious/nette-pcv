Nittro/Full
=================

This is a pre-packaged Nittro build containing all the Nittro components.

For installation instructions please see https://www.nittro.org
